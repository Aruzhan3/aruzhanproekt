# src/main.py
import os
import pandas as pd
import matplotlib.pyplot as plt

RESULTS_DIR = './results'
FIG_DIR = os.path.join(RESULTS_DIR, 'figures')
os.makedirs(FIG_DIR, exist_ok=True)

def load_results():
    df_sgd = pd.read_csv(os.path.join(RESULTS_DIR, 'history_sgd.csv'))
    df_mom = pd.read_csv(os.path.join(RESULTS_DIR, 'history_momentum.csv'))
    return df_sgd, df_mom

def compare_plots(df_sgd, df_mom):
    plt.figure(figsize=(12,5))
    # Train loss
    plt.subplot(1,2,1)
    plt.plot(df_sgd['train_loss'], label='SGD', marker='o')
    plt.plot(df_mom['train_loss'], label='Momentum', marker='o')
    plt.title('Train Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend(); plt.grid(True)

    # Accuracy
    plt.subplot(1,2,2)
    plt.plot(df_sgd['test_acc'], label='SGD', marker='o')
    plt.plot(df_mom['test_acc'], label='Momentum', marker='o')
    plt.title('Test Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.legend(); plt.grid(True)

    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'loss_acc_compare.png'))
    plt.show()

if __name__ == "__main__":
    df_sgd, df_mom = load_results()
    compare_plots(df_sgd, df_mom)
    print("Графики сохранены в ./results/figures/")
