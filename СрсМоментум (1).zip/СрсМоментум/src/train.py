# src/train.py
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import Subset, DataLoader
import numpy as np
import random
import os
import pandas as pd
import matplotlib.pyplot as plt

#CONFIG 
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
SEED = 42
SUBSET_SIZE = 8000
BATCH_SIZE = 64
EPOCHS = 20
LR = 0.01
DATA_DIR = './data'
RESULTS_DIR = './results'
os.makedirs(os.path.join(RESULTS_DIR, 'figures'), exist_ok=True)

# UTILITIES 
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def show_sample_images(loader):
    """Отображает несколько изображений из CIFAR-10"""
    data_iter = iter(loader)
    images, labels = next(data_iter)
    fig, axes = plt.subplots(2, 4, figsize=(8,4))
    for i, ax in enumerate(axes.flat):
        img = (images[i] / 2 + 0.5).permute(1,2,0)
        ax.imshow(img)
        ax.axis('off')
        ax.set_title(f"Label: {labels[i].item()}")
    plt.tight_layout()
    plt.savefig(os.path.join(RESULTS_DIR, 'figures', 'cifar_samples.png'))
    plt.show()

def get_cifar10_subset(subset_size, batch_size):
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
    ])
    train_full = datasets.CIFAR10(root=DATA_DIR, train=True, download=True, transform=transform)
    test_data = datasets.CIFAR10(root=DATA_DIR, train=False, download=True, transform=transform)
    subset_indices = np.random.choice(len(train_full), subset_size, replace=False)
    train_subset = Subset(train_full, subset_indices)
    train_loader = DataLoader(train_subset, batch_size=batch_size, shuffle=True, num_workers=2)
    test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False, num_workers=2)
    return train_loader, test_loader

#модельCNN
class SimpleCNN(nn.Module):
    def __init__(self):
        super(SimpleCNN, self).__init__()
        self.conv_layers = nn.Sequential(
            nn.Conv2d(3, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2,2),
            nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2,2)
        )
        self.fc_layers = nn.Sequential(
            nn.Flatten(),
            nn.Linear(32*8*8, 10)
        )
    def forward(self, x):
        return self.fc_layers(self.conv_layers(x))

# Деректерды окыту
def compute_grad_norm(model):
    total = 0
    for p in model.parameters():
        if p.grad is not None:
            total += p.grad.data.norm(2).item() ** 2
    return total ** 0.5

def train_model(optimizer_name, lr, momentum=0.0):
    model = SimpleCNN().to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    if optimizer_name == 'SGD':
        optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.0)
    else:
        optimizer = optim.SGD(model.parameters(), lr=lr, momentum=momentum)

    history = {'train_loss': [], 'test_acc': [], 'grad_norm': []}

    for epoch in range(EPOCHS):
        model.train()
        total_loss, grad_sum = 0, 0
        for x, y in TRAIN_LOADER:
            x, y = x.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            out = model(x)
            loss = criterion(out, y)
            loss.backward()
            grad_sum += compute_grad_norm(model)
            optimizer.step()
            total_loss += loss.item() * x.size(0)

        avg_loss = total_loss / len(TRAIN_LOADER.dataset)
        avg_grad = grad_sum / len(TRAIN_LOADER)

        # === TEST ===
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for x, y in TEST_LOADER:
                x, y = x.to(DEVICE), y.to(DEVICE)
                out = model(x)
                _, pred = torch.max(out, 1)
                correct += (pred == y).sum().item()
                total += y.size(0)
        acc = correct / total * 100

        history['train_loss'].append(avg_loss)
        history['test_acc'].append(acc)
        history['grad_norm'].append(avg_grad)

        print(f"{optimizer_name} | Epoch {epoch+1}/{EPOCHS} | Loss={avg_loss:.4f} | Acc={acc:.2f}% | Grad={avg_grad:.3f}")

    df = pd.DataFrame(history)
    df.to_csv(os.path.join(RESULTS_DIR, f"history_{optimizer_name.lower()}.csv"), index=False)
    return df

if __name__ == "__main__":
    set_seed(SEED)
    TRAIN_LOADER, TEST_LOADER = get_cifar10_subset(SUBSET_SIZE, BATCH_SIZE)
    show_sample_images(TRAIN_LOADER)
    print("Начинаем обучение моделей...")

    df_sgd = train_model('SGD', LR)
    df_mom = train_model('Momentum', LR, momentum=0.9)

    print("\nОбучение завершено. Результаты сохранены в ./results/")
