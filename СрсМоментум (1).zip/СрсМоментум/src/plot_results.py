# src/plot_results.py
import pandas as pd
import matplotlib.pyplot as plt
import os

RESULTS_DIR = './results'
FIG_DIR = os.path.join(RESULTS_DIR, 'figures')
os.makedirs(FIG_DIR, exist_ok=True)

df_sgd = pd.read_csv(os.path.join(RESULTS_DIR, 'history_sgd.csv'))
df_mom = pd.read_csv(os.path.join(RESULTS_DIR, 'history_momentum.csv'))

plt.figure(figsize=(6,4))
plt.plot(df_sgd['grad_norm'], label='SGD', marker='o')
plt.plot(df_mom['grad_norm'], label='Momentum', marker='o')
plt.title('Средняя норма градиента по эпохам')
plt.xlabel('Эпоха')
plt.ylabel('Grad Norm')
plt.legend(); plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'gradnorm_compare.png'))
plt.show()
