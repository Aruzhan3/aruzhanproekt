# CIFAR-10 Optimizer Comparison (SGD vs Momentum)

Этот мини-проект исследует влияние оптимизатора Momentum по сравнению с классическим SGD  
на скорость и качество обучения сверточной нейросети на подмножестве CIFAR-10.

Основано на идеях статьи ["Why Momentum Really Works"](https://distill.pub/2017/momentum/) (G. Goh, 2017)
Структура проекта
project/
│
├── src/
│ ├── train.py # Основное обучение (SGD и Momentum)
│ ├── plot_results.py # Построение графиков и анализ
│ └── utils/ # (опционально) вспомогательные функции
│
├── results/
│ ├── history_sgd.csv
│ ├── history_momentum.csv
│ ├── figures/
│ │ ├── cifar_samples.png
│ │ ├── loss_acc_compare.png
│ │ └── gradnorm_compare.png
│
├── README.md
└── requirements.txt

1.pip install -r requirements.txt-установка библиотек
2.python src/train.py - обучение моделей
3.python src/main.py - анализ теста
python src/plot_results.py - график 

